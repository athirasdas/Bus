import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
public class validate extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String uemail=request.getParameter("email");
        String upass=request.getParameter("pass");
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
          
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bus","root","root");
           PreparedStatement ps=con.prepareStatement("select * from login where email=? and pass=?");
           ps.setString(1,uemail);
           ps.setString(2,upass);
           ResultSet rs=ps.executeQuery();
           if(rs.next())
           { 
			 RequestDispatcher rd=request.getRequestDispatcher("enquiry.jsp");
            rd.forward(request, response);
               
           }   
               
          
           else{
           
            RequestDispatcher rd=request.getRequestDispatcher("index.html");
            rd.include(request, response);
           }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(validate.class.getName()).log(Level.SEVERE, null, ex);
            out.print(ex);
        }
           
    }
    
@Override
    public String getServletInfo() {
        return "Short description";
    }
}